```python
# Install mlxtend library
!pip install mlxtend
```

    Requirement already satisfied: mlxtend in c:\users\akshitha alluri\anaconda3\lib\site-packages (0.23.4)
    Requirement already satisfied: scipy>=1.2.1 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from mlxtend) (1.11.1)
    Requirement already satisfied: numpy>=1.16.2 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from mlxtend) (1.24.3)
    Requirement already satisfied: pandas>=0.24.2 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from mlxtend) (2.0.3)
    Requirement already satisfied: scikit-learn>=1.3.1 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from mlxtend) (1.6.1)
    Requirement already satisfied: matplotlib>=3.0.0 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from mlxtend) (3.7.2)
    Requirement already satisfied: joblib>=0.13.2 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from mlxtend) (1.2.0)
    Requirement already satisfied: contourpy>=1.0.1 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from matplotlib>=3.0.0->mlxtend) (1.0.5)
    Requirement already satisfied: cycler>=0.10 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from matplotlib>=3.0.0->mlxtend) (0.11.0)
    Requirement already satisfied: fonttools>=4.22.0 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from matplotlib>=3.0.0->mlxtend) (4.25.0)
    Requirement already satisfied: kiwisolver>=1.0.1 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from matplotlib>=3.0.0->mlxtend) (1.4.4)
    Requirement already satisfied: packaging>=20.0 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from matplotlib>=3.0.0->mlxtend) (23.1)
    Requirement already satisfied: pillow>=6.2.0 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from matplotlib>=3.0.0->mlxtend) (9.4.0)
    Requirement already satisfied: pyparsing<3.1,>=2.3.1 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from matplotlib>=3.0.0->mlxtend) (3.0.9)
    Requirement already satisfied: python-dateutil>=2.7 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from matplotlib>=3.0.0->mlxtend) (2.8.2)
    Requirement already satisfied: pytz>=2020.1 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from pandas>=0.24.2->mlxtend) (2023.3.post1)
    Requirement already satisfied: tzdata>=2022.1 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from pandas>=0.24.2->mlxtend) (2023.3)
    Requirement already satisfied: threadpoolctl>=3.1.0 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from scikit-learn>=1.3.1->mlxtend) (3.5.0)
    Requirement already satisfied: six>=1.5 in c:\users\akshitha alluri\anaconda3\lib\site-packages (from python-dateutil>=2.7->matplotlib>=3.0.0->mlxtend) (1.16.0)
    


```python
import pandas as pd
import mlxtend
from mlxtend.frequent_patterns import apriori,association_rules
import matplotlib.pyplot as plt
import numpy as np
```


```python
titanic = pd.read_csv("Titanic.csv")
titanic
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Class</th>
      <th>Gender</th>
      <th>Age</th>
      <th>Survived</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>3rd</td>
      <td>Male</td>
      <td>Child</td>
      <td>No</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3rd</td>
      <td>Male</td>
      <td>Child</td>
      <td>No</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3rd</td>
      <td>Male</td>
      <td>Child</td>
      <td>No</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3rd</td>
      <td>Male</td>
      <td>Child</td>
      <td>No</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3rd</td>
      <td>Male</td>
      <td>Child</td>
      <td>No</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>2196</th>
      <td>Crew</td>
      <td>Female</td>
      <td>Adult</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>2197</th>
      <td>Crew</td>
      <td>Female</td>
      <td>Adult</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>2198</th>
      <td>Crew</td>
      <td>Female</td>
      <td>Adult</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>2199</th>
      <td>Crew</td>
      <td>Female</td>
      <td>Adult</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>2200</th>
      <td>Crew</td>
      <td>Female</td>
      <td>Adult</td>
      <td>Yes</td>
    </tr>
  </tbody>
</table>
<p>2201 rows × 4 columns</p>
</div>




```python
titanic.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2201 entries, 0 to 2200
    Data columns (total 4 columns):
     #   Column    Non-Null Count  Dtype 
    ---  ------    --------------  ----- 
     0   Class     2201 non-null   object
     1   Gender    2201 non-null   object
     2   Age       2201 non-null   object
     3   Survived  2201 non-null   object
    dtypes: object(4)
    memory usage: 68.9+ KB
    

### Observations
* There are no null values
* Total are 4 columns class, Gender, Age, Survived
* all the columns are object data type and categorical in nature
* As the columns are categorical, we can adopt one-hot-encoding


```python
# plot a bar chart to visualize the category of class on the ship
counts = titanic['Class'].value_counts()
plt.bar(counts.index, counts.values)
```




    <BarContainer object of 4 artists>




    
![png](output_5_1.png)
    



```python
counts = titanic['Gender'].value_counts()
plt.bar(counts.index, counts.values)
```




    <BarContainer object of 2 artists>




    
![png](output_6_1.png)
    



```python
counts = titanic['Age'].value_counts()
plt.bar(counts.index, counts.values)
```




    <BarContainer object of 2 artists>




    
![png](output_7_1.png)
    



```python
counts = titanic['Survived'].value_counts()
plt.bar(counts.index, counts.values)
```




    <BarContainer object of 2 artists>




    
![png](output_8_1.png)
    



```python
# perform one-hot-encoding on categorical columns
df = pd.get_dummies(titanic, dtype=int)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Class_1st</th>
      <th>Class_2nd</th>
      <th>Class_3rd</th>
      <th>Class_Crew</th>
      <th>Gender_Female</th>
      <th>Gender_Male</th>
      <th>Age_Adult</th>
      <th>Age_Child</th>
      <th>Survived_No</th>
      <th>Survived_Yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 2201 entries, 0 to 2200
    Data columns (total 10 columns):
     #   Column         Non-Null Count  Dtype
    ---  ------         --------------  -----
     0   Class_1st      2201 non-null   int32
     1   Class_2nd      2201 non-null   int32
     2   Class_3rd      2201 non-null   int32
     3   Class_Crew     2201 non-null   int32
     4   Gender_Female  2201 non-null   int32
     5   Gender_Male    2201 non-null   int32
     6   Age_Adult      2201 non-null   int32
     7   Age_Child      2201 non-null   int32
     8   Survived_No    2201 non-null   int32
     9   Survived_Yes   2201 non-null   int32
    dtypes: int32(10)
    memory usage: 86.1 KB
    

### Apriori Algorithm


```python
# apply apriori algorithm to get itemset combinations
frequent_itemsets = apriori(df, min_support=0.05, use_colnames=True, max_len=None)
frequent_itemsets
```

    C:\Users\akshitha alluri\anaconda3\Lib\site-packages\mlxtend\frequent_patterns\fpcommon.py:161: DeprecationWarning: DataFrames with non-bool types result in worse computationalperformance and their support might be discontinued in the future.Please use a DataFrame with bool type
      warnings.warn(
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>support</th>
      <th>itemsets</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.147660</td>
      <td>(Class_1st)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.129487</td>
      <td>(Class_2nd)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.320763</td>
      <td>(Class_3rd)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.402090</td>
      <td>(Class_Crew)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.213539</td>
      <td>(Gender_Female)</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>58</th>
      <td>0.053612</td>
      <td>(Gender_Male, Class_1st, Age_Adult, Survived_No)</td>
    </tr>
    <tr>
      <th>59</th>
      <td>0.069968</td>
      <td>(Class_2nd, Gender_Male, Age_Adult, Survived_No)</td>
    </tr>
    <tr>
      <th>60</th>
      <td>0.175829</td>
      <td>(Gender_Male, Class_3rd, Age_Adult, Survived_No)</td>
    </tr>
    <tr>
      <th>61</th>
      <td>0.304407</td>
      <td>(Class_Crew, Gender_Male, Age_Adult, Survived_No)</td>
    </tr>
    <tr>
      <th>62</th>
      <td>0.087233</td>
      <td>(Class_Crew, Survived_Yes, Gender_Male, Age_Ad...</td>
    </tr>
  </tbody>
</table>
<p>63 rows × 2 columns</p>
</div>




```python
#Generate association rules with metrics
rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1.0)
rules
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>antecedents</th>
      <th>consequents</th>
      <th>antecedent support</th>
      <th>consequent support</th>
      <th>support</th>
      <th>confidence</th>
      <th>lift</th>
      <th>representativity</th>
      <th>leverage</th>
      <th>conviction</th>
      <th>zhangs_metric</th>
      <th>jaccard</th>
      <th>certainty</th>
      <th>kulczynski</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>(Gender_Female)</td>
      <td>(Class_1st)</td>
      <td>0.213539</td>
      <td>0.147660</td>
      <td>0.065879</td>
      <td>0.308511</td>
      <td>2.089329</td>
      <td>1.0</td>
      <td>0.034348</td>
      <td>1.232615</td>
      <td>0.662941</td>
      <td>0.223077</td>
      <td>0.188716</td>
      <td>0.377332</td>
    </tr>
    <tr>
      <th>1</th>
      <td>(Class_1st)</td>
      <td>(Gender_Female)</td>
      <td>0.147660</td>
      <td>0.213539</td>
      <td>0.065879</td>
      <td>0.446154</td>
      <td>2.089329</td>
      <td>1.0</td>
      <td>0.034348</td>
      <td>1.419998</td>
      <td>0.611701</td>
      <td>0.223077</td>
      <td>0.295774</td>
      <td>0.377332</td>
    </tr>
    <tr>
      <th>2</th>
      <td>(Class_1st)</td>
      <td>(Age_Adult)</td>
      <td>0.147660</td>
      <td>0.950477</td>
      <td>0.144934</td>
      <td>0.981538</td>
      <td>1.032680</td>
      <td>1.0</td>
      <td>0.004587</td>
      <td>2.682493</td>
      <td>0.037128</td>
      <td>0.152050</td>
      <td>0.627212</td>
      <td>0.567012</td>
    </tr>
    <tr>
      <th>3</th>
      <td>(Age_Adult)</td>
      <td>(Class_1st)</td>
      <td>0.950477</td>
      <td>0.147660</td>
      <td>0.144934</td>
      <td>0.152486</td>
      <td>1.032680</td>
      <td>1.0</td>
      <td>0.004587</td>
      <td>1.005694</td>
      <td>0.639010</td>
      <td>0.152050</td>
      <td>0.005661</td>
      <td>0.567012</td>
    </tr>
    <tr>
      <th>4</th>
      <td>(Survived_Yes)</td>
      <td>(Class_1st)</td>
      <td>0.323035</td>
      <td>0.147660</td>
      <td>0.092231</td>
      <td>0.285513</td>
      <td>1.933584</td>
      <td>1.0</td>
      <td>0.044531</td>
      <td>1.192940</td>
      <td>0.713221</td>
      <td>0.243697</td>
      <td>0.161735</td>
      <td>0.455064</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>159</th>
      <td>(Survived_Yes, Gender_Male)</td>
      <td>(Class_Crew, Age_Adult)</td>
      <td>0.166742</td>
      <td>0.402090</td>
      <td>0.087233</td>
      <td>0.523161</td>
      <td>1.301104</td>
      <td>1.0</td>
      <td>0.020188</td>
      <td>1.253903</td>
      <td>0.277731</td>
      <td>0.181132</td>
      <td>0.202490</td>
      <td>0.370055</td>
    </tr>
    <tr>
      <th>160</th>
      <td>(Gender_Male, Age_Adult)</td>
      <td>(Class_Crew, Survived_Yes)</td>
      <td>0.757383</td>
      <td>0.096320</td>
      <td>0.087233</td>
      <td>0.115177</td>
      <td>1.195776</td>
      <td>1.0</td>
      <td>0.014282</td>
      <td>1.021312</td>
      <td>0.674821</td>
      <td>0.113811</td>
      <td>0.020867</td>
      <td>0.510419</td>
    </tr>
    <tr>
      <th>161</th>
      <td>(Class_Crew)</td>
      <td>(Survived_Yes, Gender_Male, Age_Adult)</td>
      <td>0.402090</td>
      <td>0.153567</td>
      <td>0.087233</td>
      <td>0.216949</td>
      <td>1.412737</td>
      <td>1.0</td>
      <td>0.025486</td>
      <td>1.080943</td>
      <td>0.488626</td>
      <td>0.186227</td>
      <td>0.074882</td>
      <td>0.392498</td>
    </tr>
    <tr>
      <th>162</th>
      <td>(Gender_Male)</td>
      <td>(Class_Crew, Survived_Yes, Age_Adult)</td>
      <td>0.786461</td>
      <td>0.096320</td>
      <td>0.087233</td>
      <td>0.110919</td>
      <td>1.151565</td>
      <td>1.0</td>
      <td>0.011481</td>
      <td>1.016420</td>
      <td>0.616356</td>
      <td>0.109652</td>
      <td>0.016155</td>
      <td>0.508289</td>
    </tr>
    <tr>
      <th>163</th>
      <td>(Age_Adult)</td>
      <td>(Class_Crew, Survived_Yes, Gender_Male)</td>
      <td>0.950477</td>
      <td>0.087233</td>
      <td>0.087233</td>
      <td>0.091778</td>
      <td>1.052103</td>
      <td>1.0</td>
      <td>0.004320</td>
      <td>1.005004</td>
      <td>1.000000</td>
      <td>0.091778</td>
      <td>0.004980</td>
      <td>0.545889</td>
    </tr>
  </tbody>
</table>
<p>164 rows × 14 columns</p>
</div>




```python
rules.sort_values(by='lift', ascending = False)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>antecedents</th>
      <th>consequents</th>
      <th>antecedent support</th>
      <th>consequent support</th>
      <th>support</th>
      <th>confidence</th>
      <th>lift</th>
      <th>representativity</th>
      <th>leverage</th>
      <th>conviction</th>
      <th>zhangs_metric</th>
      <th>jaccard</th>
      <th>certainty</th>
      <th>kulczynski</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>107</th>
      <td>(Survived_Yes, Class_1st)</td>
      <td>(Gender_Female, Age_Adult)</td>
      <td>0.092231</td>
      <td>0.193094</td>
      <td>0.063607</td>
      <td>0.689655</td>
      <td>3.571602</td>
      <td>1.0</td>
      <td>0.045798</td>
      <td>2.600030</td>
      <td>0.793168</td>
      <td>0.286885</td>
      <td>0.615389</td>
      <td>0.509533</td>
    </tr>
    <tr>
      <th>110</th>
      <td>(Gender_Female, Age_Adult)</td>
      <td>(Survived_Yes, Class_1st)</td>
      <td>0.193094</td>
      <td>0.092231</td>
      <td>0.063607</td>
      <td>0.329412</td>
      <td>3.571602</td>
      <td>1.0</td>
      <td>0.045798</td>
      <td>1.353691</td>
      <td>0.892314</td>
      <td>0.286885</td>
      <td>0.261279</td>
      <td>0.509533</td>
    </tr>
    <tr>
      <th>113</th>
      <td>(Gender_Female)</td>
      <td>(Survived_Yes, Class_1st, Age_Adult)</td>
      <td>0.213539</td>
      <td>0.089505</td>
      <td>0.063607</td>
      <td>0.297872</td>
      <td>3.328005</td>
      <td>1.0</td>
      <td>0.044495</td>
      <td>1.296766</td>
      <td>0.889453</td>
      <td>0.265655</td>
      <td>0.228851</td>
      <td>0.504266</td>
    </tr>
    <tr>
      <th>104</th>
      <td>(Survived_Yes, Class_1st, Age_Adult)</td>
      <td>(Gender_Female)</td>
      <td>0.089505</td>
      <td>0.213539</td>
      <td>0.063607</td>
      <td>0.710660</td>
      <td>3.328005</td>
      <td>1.0</td>
      <td>0.044495</td>
      <td>2.718119</td>
      <td>0.768285</td>
      <td>0.265655</td>
      <td>0.632098</td>
      <td>0.504266</td>
    </tr>
    <tr>
      <th>36</th>
      <td>(Gender_Female)</td>
      <td>(Survived_Yes, Class_1st)</td>
      <td>0.213539</td>
      <td>0.092231</td>
      <td>0.064062</td>
      <td>0.300000</td>
      <td>3.252709</td>
      <td>1.0</td>
      <td>0.044367</td>
      <td>1.296813</td>
      <td>0.880609</td>
      <td>0.265038</td>
      <td>0.228879</td>
      <td>0.497291</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>24</th>
      <td>(Age_Adult)</td>
      <td>(Survived_No)</td>
      <td>0.950477</td>
      <td>0.676965</td>
      <td>0.653339</td>
      <td>0.687380</td>
      <td>1.015386</td>
      <td>1.0</td>
      <td>0.009900</td>
      <td>1.033317</td>
      <td>0.305968</td>
      <td>0.670709</td>
      <td>0.032243</td>
      <td>0.826241</td>
    </tr>
    <tr>
      <th>20</th>
      <td>(Gender_Male)</td>
      <td>(Age_Adult)</td>
      <td>0.786461</td>
      <td>0.950477</td>
      <td>0.757383</td>
      <td>0.963027</td>
      <td>1.013204</td>
      <td>1.0</td>
      <td>0.009870</td>
      <td>1.339441</td>
      <td>0.061028</td>
      <td>0.773191</td>
      <td>0.253420</td>
      <td>0.879936</td>
    </tr>
    <tr>
      <th>21</th>
      <td>(Age_Adult)</td>
      <td>(Gender_Male)</td>
      <td>0.950477</td>
      <td>0.786461</td>
      <td>0.757383</td>
      <td>0.796845</td>
      <td>1.013204</td>
      <td>1.0</td>
      <td>0.009870</td>
      <td>1.051116</td>
      <td>0.263149</td>
      <td>0.773191</td>
      <td>0.048630</td>
      <td>0.879936</td>
    </tr>
    <tr>
      <th>121</th>
      <td>(Age_Adult, Survived_No)</td>
      <td>(Gender_Male, Class_1st)</td>
      <td>0.653339</td>
      <td>0.081781</td>
      <td>0.053612</td>
      <td>0.082058</td>
      <td>1.003392</td>
      <td>1.0</td>
      <td>0.000181</td>
      <td>1.000302</td>
      <td>0.009752</td>
      <td>0.078667</td>
      <td>0.000302</td>
      <td>0.368807</td>
    </tr>
    <tr>
      <th>118</th>
      <td>(Gender_Male, Class_1st)</td>
      <td>(Age_Adult, Survived_No)</td>
      <td>0.081781</td>
      <td>0.653339</td>
      <td>0.053612</td>
      <td>0.655556</td>
      <td>1.003392</td>
      <td>1.0</td>
      <td>0.000181</td>
      <td>1.006434</td>
      <td>0.003682</td>
      <td>0.078667</td>
      <td>0.006393</td>
      <td>0.368807</td>
    </tr>
  </tbody>
</table>
<p>164 rows × 14 columns</p>
</div>



### Conclusion 
* Adult females travelling in 1st class were among the most survived


```python
import matplotlib.pyplot as plt
rules[['support','confidence','lift']].hist(figsize=(15,7))
plt.show()
```


    
![png](output_16_0.png)
    



```python
### Observations
* The highest frequency range is 
* The highest support range is 
* The highest confidence range is 
```


```python
import matplotlib.pyplot as plt
plt.scatter(rules['support'], rules['confidence'])
plt.xlabel('support')
plt.ylabel('confidence')
plt.show()
```


    
![png](output_18_0.png)
    


* The confidence value is increasing with increase in support for most 


```python
plt.scatter(rules['confidence'], rules['lift'])
plt.show()
```


    
![png](output_20_0.png)
    



```python
rules[rules["consequents"]==({"Survived_Yes"})]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>antecedents</th>
      <th>consequents</th>
      <th>antecedent support</th>
      <th>consequent support</th>
      <th>support</th>
      <th>confidence</th>
      <th>lift</th>
      <th>representativity</th>
      <th>leverage</th>
      <th>conviction</th>
      <th>zhangs_metric</th>
      <th>jaccard</th>
      <th>certainty</th>
      <th>kulczynski</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5</th>
      <td>(Class_1st)</td>
      <td>(Survived_Yes)</td>
      <td>0.147660</td>
      <td>0.323035</td>
      <td>0.092231</td>
      <td>0.624615</td>
      <td>1.933584</td>
      <td>1.0</td>
      <td>0.044531</td>
      <td>1.803390</td>
      <td>0.566471</td>
      <td>0.243697</td>
      <td>0.445489</td>
      <td>0.455064</td>
    </tr>
    <tr>
      <th>6</th>
      <td>(Class_2nd)</td>
      <td>(Survived_Yes)</td>
      <td>0.129487</td>
      <td>0.323035</td>
      <td>0.053612</td>
      <td>0.414035</td>
      <td>1.281704</td>
      <td>1.0</td>
      <td>0.011783</td>
      <td>1.155300</td>
      <td>0.252481</td>
      <td>0.134396</td>
      <td>0.134424</td>
      <td>0.289999</td>
    </tr>
    <tr>
      <th>19</th>
      <td>(Gender_Female)</td>
      <td>(Survived_Yes)</td>
      <td>0.213539</td>
      <td>0.323035</td>
      <td>0.156293</td>
      <td>0.731915</td>
      <td>2.265745</td>
      <td>1.0</td>
      <td>0.087312</td>
      <td>2.525187</td>
      <td>0.710327</td>
      <td>0.410992</td>
      <td>0.603990</td>
      <td>0.607870</td>
    </tr>
    <tr>
      <th>34</th>
      <td>(Gender_Female, Class_1st)</td>
      <td>(Survived_Yes)</td>
      <td>0.065879</td>
      <td>0.323035</td>
      <td>0.064062</td>
      <td>0.972414</td>
      <td>3.010243</td>
      <td>1.0</td>
      <td>0.042781</td>
      <td>24.539982</td>
      <td>0.714898</td>
      <td>0.197203</td>
      <td>0.959250</td>
      <td>0.585363</td>
    </tr>
    <tr>
      <th>46</th>
      <td>(Class_1st, Age_Adult)</td>
      <td>(Survived_Yes)</td>
      <td>0.144934</td>
      <td>0.323035</td>
      <td>0.089505</td>
      <td>0.617555</td>
      <td>1.911727</td>
      <td>1.0</td>
      <td>0.042686</td>
      <td>1.770097</td>
      <td>0.557750</td>
      <td>0.236495</td>
      <td>0.435059</td>
      <td>0.447315</td>
    </tr>
    <tr>
      <th>93</th>
      <td>(Gender_Female, Age_Adult)</td>
      <td>(Survived_Yes)</td>
      <td>0.193094</td>
      <td>0.323035</td>
      <td>0.143571</td>
      <td>0.743529</td>
      <td>2.301699</td>
      <td>1.0</td>
      <td>0.081195</td>
      <td>2.639542</td>
      <td>0.700873</td>
      <td>0.385366</td>
      <td>0.621146</td>
      <td>0.593987</td>
    </tr>
    <tr>
      <th>105</th>
      <td>(Gender_Female, Class_1st, Age_Adult)</td>
      <td>(Survived_Yes)</td>
      <td>0.065425</td>
      <td>0.323035</td>
      <td>0.063607</td>
      <td>0.972222</td>
      <td>3.009650</td>
      <td>1.0</td>
      <td>0.042473</td>
      <td>24.370741</td>
      <td>0.714480</td>
      <td>0.195804</td>
      <td>0.958967</td>
      <td>0.584564</td>
    </tr>
  </tbody>
</table>
</div>




```python

```
